<?php

namespace App\Repository;
use App\Entity\AbsencePermission;
use App\Entity\Absence;
use App\Entity\Intern;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method Absence|null find($id, $lockMode = null, $lockVersion = null)
 * @method Absence|null findOneBy(array $criteria, array $orderBy = null)
 * @method Absence[]    findAll()
 * @method Absence[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class AbsenceRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Absence::class);
    }

   /**
      * @return Query
      */
    /* public function myFindAllAbsence()
     {
    return $this->findAbsence()
                ->getQuery();

    }*/
    public function  myFindAllAbsence($id) {
    return $this->_em->createQuery("
        SELECT i.id,u.firstName,a.state,a.dateAbsence,a.motif,a.justification,a.nbHours,a.id as AbsenceId
        FROM App:Absence a,App:Intern i,App:User u
        WHERE  i.id=a.intern AND u.id=i.user AND i.id='".$id."'
    ")->getResult();
    }

   
     public function  myFindId($id) {

    return $this->_em->createQuery("
        SELECT i.id
        FROM App:Absence a,App:Intern i,App:User u
        WHERE  i.id=a.intern AND u.id='".$id."'
    ")->getResult();
    }

    // /**
    //  * @return Absence[] Returns an array of Absence objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('a')
            ->andWhere('a.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('a.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Absence
    {
        return $this->createQueryBuilder('a')
            ->andWhere('a.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
