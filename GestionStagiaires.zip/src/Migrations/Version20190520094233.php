<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190520094233 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('CREATE TABLE intern (id INT AUTO_INCREMENT NOT NULL, user_id INT DEFAULT NULL, school VARCHAR(100) NOT NULL, country VARCHAR(25) NOT NULL, city VARCHAR(25) NOT NULL, formation VARCHAR(255) NOT NULL, speciality VARCHAR(100) NOT NULL, level VARCHAR(25) NOT NULL, cv VARCHAR(255) NOT NULL, birthday DATE NOT NULL, UNIQUE INDEX UNIQ_A5795F36A76ED395 (user_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE internship (id INT AUTO_INCREMENT NOT NULL, intern_id INT NOT NULL, topic_id INT NOT NULL, start_date DATE NOT NULL, duration INT NOT NULL, created_at DATETIME DEFAULT NULL, updated_at DATETIME DEFAULT NULL, deleted_at DATETIME DEFAULT NULL, INDEX IDX_10D1B00C525DD4B4 (intern_id), INDEX IDX_10D1B00C1F55203D (topic_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE topic (id INT AUTO_INCREMENT NOT NULL, title VARCHAR(255) NOT NULL, description LONGTEXT NOT NULL, document VARCHAR(255) NOT NULL, state VARCHAR(4) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME DEFAULT NULL, deleted_at DATETIME DEFAULT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('CREATE TABLE user (id INT AUTO_INCREMENT NOT NULL, user_name VARCHAR(25) NOT NULL, last_name VARCHAR(25) NOT NULL, first_name VARCHAR(25) NOT NULL, adresse VARCHAR(50) NOT NULL, email VARCHAR(50) NOT NULL, phone VARCHAR(25) NOT NULL, photo VARCHAR(255) NOT NULL, is_active TINYINT(1) NOT NULL, password VARCHAR(255) NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME DEFAULT NULL, deleted_at DATETIME DEFAULT NULL, nic VARCHAR(10) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci ENGINE = InnoDB');
        $this->addSql('ALTER TABLE intern ADD CONSTRAINT FK_A5795F36A76ED395 FOREIGN KEY (user_id) REFERENCES user (id)');
        $this->addSql('ALTER TABLE internship ADD CONSTRAINT FK_10D1B00C525DD4B4 FOREIGN KEY (intern_id) REFERENCES intern (id)');
        $this->addSql('ALTER TABLE internship ADD CONSTRAINT FK_10D1B00C1F55203D FOREIGN KEY (topic_id) REFERENCES topic (id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE internship DROP FOREIGN KEY FK_10D1B00C525DD4B4');
        $this->addSql('ALTER TABLE internship DROP FOREIGN KEY FK_10D1B00C1F55203D');
        $this->addSql('ALTER TABLE intern DROP FOREIGN KEY FK_A5795F36A76ED395');
        $this->addSql('DROP TABLE intern');
        $this->addSql('DROP TABLE internship');
        $this->addSql('DROP TABLE topic');
        $this->addSql('DROP TABLE user');
    }
}
