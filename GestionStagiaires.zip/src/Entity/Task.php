<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\TaskRepository")
 */
class Task
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $title;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $description;

    /**
     * @ORM\Column(type="datetime")
     */
    private $startDate;

    /**
     * @ORM\Column(type="integer")
     */
    private $estimationSupervisor;

    /**
     * @ORM\Column(type="integer",nullable=true)
     */
    private $estimationIntern;

    /**
     * @ORM\Column(type="string", length=20)
     */
    private $state;

    /**
     * @ORM\Column(type="datetime")
     */
    private $createdAt;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $deletedAt;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Topic", inversedBy="tasks")
     */
    private $topicTask;

    
    public function __construct()
    {
        $this->topicTask = new ArrayCollection();
        $this->intern = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): self
    {
        $this->title = $title;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getStartDate(): ?\DateTimeInterface
    {
        return $this->startDate;
    }

    public function setStartDate(\DateTimeInterface $startDate): self
    {
        $this->startDate = $startDate;

        return $this;
    }

    public function getEstimationSupervisor(): ?int
    {
        return $this->estimationSupervisor;
    }

    public function setEstimationSupervisor(int $estimationSupervisor): self
    {
        $this->estimationSupervisor = $estimationSupervisor;

        return $this;
    }

    public function getEstimationIntern(): ?int
    {
        return $this->estimationIntern;
    }

    public function setEstimationIntern(int $estimationIntern): self
    {
        $this->estimationIntern = $estimationIntern;

        return $this;
    }

    public function getState(): ?string
    {
        return $this->state;
    }

    public function setState(string $state): self
    {
        $this->state = $state;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function getDeletedAt(): ?\DateTimeInterface
    {
        return $this->deletedAt;
    }

    public function setDeletedAt(\DateTimeInterface $deletedAt): self
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * @return Collection|Topic[]
     */
    public function getTopicTask(): Collection
    {
        return $this->topicTask;
    }

    public function addTopicTask(Topic $topicTask): self
    {
        if (!$this->topicTask->contains($topicTask)) {
            $this->topicTask[] = $topicTask;
        }

        return $this;
    }

    public function removeTopicTask(Topic $topicTask): self
    {
        if ($this->topicTask->contains($topicTask)) {
            $this->topicTask->removeElement($topicTask);
        }

        return $this;
    }








    


}
