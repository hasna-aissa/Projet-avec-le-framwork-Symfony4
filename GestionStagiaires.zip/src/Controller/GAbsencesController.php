<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Intern;
use App\Entity\Absence;
use App\Entity\AbsencePermission;
use App\Form\AbsencePermissionFormType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Dompdf\Dompdf;
use Dompdf\Options;
use Knp\Component\Pager\PaginatorInterface; 

class GAbsencesController extends AbstractController
{
    /**
     * @Route("/g/absences", name="g_absences")
     */
    public function index()
    {
        return $this->render('g_absences/index.html.twig', [
            'controller_name' => 'GAbsencesController',
        ]);
    }

    /**
     * @Route("st-imalia/Absences/DetailsAbs/{id}", name="DetailsAbs")
     */
    public function DetailsAbs($id)
    {

       $Absence= $this->getDoctrine()->getRepository(Absence::class)->find($id);
       $stagiaires=$this->getDoctrine()->getRepository(Intern::class)->find($Absence->getIntern());
       return $this->render('g_absences/DetailsAbs.html.twig',array('Absence' => $Absence,'stagiaires' => $stagiaires));

    }



    /**
     * @Route("st-imalia/Absences/CalendarAbsence", name="CalendarAbsence")
     */
    public function CalendarAbsence()
    {
        return $this->render('g_absences/CalendarAbsence.html.twig', [
            'controller_name' => 'GAbsencesController',
        ]);
    }

    /**
     * @Route("st-imalia/Absences/ListeAbsences", name="ListeAbsences")
     */
    public function ListeAbsences()
    {
        return $this->render('g_absences/ListeAbsences.html.twig', [
            'controller_name' => 'GAbsencesController',
        ]);
    }

    /**
     * @Route("st-imalia/Absences/MesAbsences", name="MesAbsences")
     */
    public function MesAbsences(Request $request, ObjectManager $manager,PaginatorInterface $paginator)
    {
      $manager = $this->getDoctrine()->getManager();
      //$userCurrent = $this->getUser();
     
      //$id=$userCurrent->getId();
      
        //repos
        //eneityRepo
       $AbsenceRepo=  $manager->getRepository('App:Absence');

       $userCurrent = $this->getUser();
     
        $id=$userCurrent->getId();
        $intern =$this->getDoctrine()->getRepository(Intern::class)->findOneBy(['user' => $id]);
        $stagiaires =$AbsenceRepo->myFindAllAbsence($intern->getId());
        //Ajout
         $absencePermission = new AbsencePermission();
        $form = $this->createForm(AbsencePermissionFormType::class, $absencePermission);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();
            //justification
             $fileIntern = $absencePermission->getJustification();
            $fileNameIntern = md5(uniqid()).'.'.$fileIntern->guessExtension();
            $fileIntern->move(
                $this->getParameter('Justification_directory'),
                $fileNameIntern
            );

            //contruct  
            $absencePermission->setState(false) 
                              ->setIntern($intern) 
                              ->setCreatedAt(new \DateTime())
                              ->setJustification($fileNameIntern);
            // Persist 
            $manager->persist($absencePermission); 

            // flush DB
            $manager->flush();   

            return $this->redirectToRoute('MesAbsences');
        }
          $stagiairess = array();
            $stagiairess = $paginator->paginate(
                                    $AbsenceRepo->myFindAllAbsence($intern->getId()),
                                    $request->query->getInt('page',1,2),
                                    1
                                     );


        return $this->render('g_absences/MesAbsences.html.twig',array('stagiaires' => $stagiaires,'stagiairess' => $stagiairess,'AbsencePermissionForm' => $form->createView()));
    }

    /**
     * @Route("st-imalia/Absences/MesAbsences/telechargerMesAbsence", name="telechargerListeMesAbsence")
     */
    public function download_list_MesAbsences()
    {
       $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
       $AbsenceRepo=  $manager->getRepository('App:Absence');

       $userCurrent = $this->getUser();
     
        $id=$userCurrent->getId();
        $intern =$this->getDoctrine()->getRepository(Intern::class)->findOneBy(['user' => $id]);

        $stagiaires = $AbsenceRepo->myFindAllAbsence($intern->getId());
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_absences/telechargerListeMesAbsence.html.twig', [
            'stagiaires' => $stagiaires
        ]);
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listMesAbsences.pdf", [
            "Attachment" => false
        ]);
    }


}
