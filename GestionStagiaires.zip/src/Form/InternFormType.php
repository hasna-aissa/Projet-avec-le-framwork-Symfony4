<?php

namespace App\Form;

use App\Entity\Intern;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\FileType;

class InternFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('school')
            ->add('country')
            ->add('city')
            ->add('formation')
            ->add('speciality')
            ->add('level')
            ->add('cv', FileType::class,['data_class'=> null,'required' => false])
            ->add('birthday')
            ->add('user',UserFormType::class)
            ->add('internships',CollectionType::class,[
                  'entry_type' => InternshipsFormType::class,
                  'entry_options' => ['label' => false], 
                  'allow_add' => true,
                  'prototype' => true,
                //'by_reference'=> false,
                //'allow_delete' => true, 
                ])
            ->add('Enregistrer', SubmitType::class)->getForm();
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Intern::class,
        ]);
    }
}