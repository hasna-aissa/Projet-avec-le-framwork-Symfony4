<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Supervisor;
use App\Entity\user;
use App\Entity\Intern;
use App\Repository\InternRepository;
use Symfony\Component\Form\FormView;
use App\Repository\SupervisorRepository;
use App\Form\UserFormType;
use App\Form\SupervisorFormType;
use App\GlobaleServices\FichierConvert;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Knp\Component\Pager\PaginatorInterface; 
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\HttpFoundation\JsonResponse;

class AjaxController extends AbstractController
{
 /**
     * @Route("st-imalia/Supervisor/ajax", name="ajax")
     */
public function ajaxAction(Request $request,ObjectManager $manager) {  
   if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
   { 
         $manager=$this->getDoctrine()->getManager();
      $supervisorRepository= $manager->getRepository('App:Supervisor'); 
         $t1 = $request->request->get('search');
         $supervisors=$supervisorRepository->SearchSupervisors($t1,1);
       $jsonData = array();
       $idx = 0;  
       foreach($supervisors as $supervisor) {  
           $temp = array(
              'service' => $supervisor['lastName'],  
              'city' => $supervisor['firstName'],  
           );   
        $jsonData[$idx++] = $temp;  
      } 
      return new JsonResponse($jsonData); 
   } else { 
      return $this->render('ajax/testAjax.html.twig'); 
   } 
} 
}
