<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Intern;
use App\Entity\User;
use App\Entity\Internship;
use App\Entity\Topic;
use Symfony\Component\Form\FormView;
use App\Repository\InternRepository;
use App\Form\UserFormType;
use App\Form\InternFormType;
use App\Form\InternshipsFormType;
use Symfony\Component\Form\Extension\Core\Type\CollectionType;
use Symfony\Component\HttpFoundation\File\Exception\FileException;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Dompdf\Dompdf;
use Dompdf\Options;
use Knp\Component\Pager\PaginatorInterface; 
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;


class GStagiairesController extends AbstractController
{
    /**
     * @Route("/g/stagiaires", name="g_stagiaires")
     */
    public function index()
    {
        return $this->render('g_stagiaires/index.html.twig', [
            'controller_name' => 'GStagiairesController',
        ]);
    }

    /**
     * @Route("st-imalia/intern/desactiver/{id}", name="stagiaire_desactiver")
     */

    public function stagiaire_desactiver($id)
   { 

        $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
        $UserRepo=  $manager->getRepository('App:User');
        $users =$UserRepo->desactivateUser($id);

     return $this->redirectToRoute('stagiaire_liste', array('users' => $users));
     
    }
      /**
     * @Route("st-imalia/intern/list", name="stagiaire_liste")
     */
    public function stagiaires_liste(PaginatorInterface $paginator, Request $request )
    {
       $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
       $InternRepo=  $manager->getRepository('App:Intern');

       $users = array();
       $message="";
       

        $form = $this->createFormBuilder(null)
                     ->add('input') 
                     ->add('rechercher', SubmitType::class)
                     ->getForm();

        $form->handleRequest($request); 
            
       if($form->isSubmitted()){
            $data = $form->getData();  
            //dump($data['input']);exit;
            $mot = $data['input'];
            $users = $paginator->paginate($InternRepo->searchResults($mot),
                                    $request->query->getInt('page',1),
                                    16
                                     );

            if ($users==NULL) {
                $message="Aucun résultat n'a été trouvé !!";
            }

            //dump($resultats);exit;
        }
        else{
            //$paginator  = $this->get('knp_paginator');
            $users = $paginator->paginate($InternRepo->myFindAll(),
                                    $request->query->getInt('page',1),
                                    16
                                     );
           
        }

       return $this->render('g_stagiaires/admin_liste_stagiaires.html.twig',
        array('users' => $users,
              'SearchForm' => $form->createView(),
              'message' => $message));
    }
     /**
     * @Route("st-imalia/intern/add", name="stagiaire_ajouter")
     */
       public function stagiaire_ajouter(Request $request, ObjectManager $manager,UserPasswordEncoderInterface $encoder)
    {
        $intern = new Intern();
        $form = $this->createForm(InternFormType::class, $intern);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();

       //contruct User infos 
            $user = $intern->getUser();

          //username   todo : add to Global service 
            $first=substr($user->getLastName(),0, 1);
            $last=substr($user->getFirstName(),0, 2);
            $UserName=strtoupper($first.$last);
            $user->setUserName($UserName);

            //photo
            //start file
            $file = $user->getPhoto();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move(
                $this->getParameter('photos_directory'),
                $fileName
            );
            //cv
            $fileIntern = $intern->getCv();
            $fileNameIntern = md5(uniqid()).'.'.$fileIntern->guessExtension();
            $fileIntern->move(
                $this->getParameter('cvs_directory'),
                $fileNameIntern
            );


          //password  todo : add to Global service 
        
            $password=$user->getLastName();
            $user->setPassword($password);

          //isActive
            $user->setIsActive(true) ;
            
          //CreatedAt  
            $user->setUserName($UserName)
                ->setPhoto($fileName)
                ->setCreatedAt(new \DateTime());

          //Photo if exist
            /*
            if($user->getPhoto()){
                $file = $user->getPhoto();
                $fileName = md5(uniqid()).'.'.$file->guessExtension();
                $file->move(
                    $this->getParameter('photos_directory'),
                    $fileName
                );
                 $user->setPhoto($fileName);
             };
            */

    //persist user   
        $hash= $encoder->encodePassword($user,$user->getPassword());
        $user->setPassword($hash);
        $manager->persist($user);


        //contruct Internship infos  

          //get internship 
            $internships[] = $intern->getInternships()->toArray();
            $internship = (object)$internships[0]["__name__"];

          //CreateAt
            $internship->setCreatedAt(new \DateTime()); 

        //persist internship     
        $manager->persist($internship);

        
        // Contruct Intern infos
            //
        $intern->setCv($fileNameIntern);
          //user
            $intern->setUser($user);

          //Internship
            $intern->addInternship($internship);
          
          //CV  
            /*
            if($intern->getCv()){
                $fileIntern = $intern->getCv();
                $fileNameIntern = md5(uniqid()).'.'.$fileIntern->guessExtension();
                $fileIntern->move(
                    $this->getParameter('cvs_directory'),
                    $fileNameIntern
                );
                $intern->setCV($fileIntern);
            }
            */

        // Persist Intern
            $manager->persist($intern); 


        // flush DB
             $manager->flush();   

        return $this->redirectToRoute('stagiaire_liste');
        }
            return $this->render('g_stagiaires/admin_stagiaire_ajouter.html.twig', array(
                'InternForm' => $form->createView())
                );
    }


   
    /**
     * @Route("st-imalia/intern/edit/{id}", name="stagiaire_modifier")
     */
    public function stagiaire_modifier(Request $request, ObjectManager $manager,$id)
    {
        //entity manager 
        $manager = $this->getDoctrine()->getManager();
        //Repositories
        $internRepo = $manager->getRepository('App:Intern');
        $internshipRepo = $manager->getRepository('App:Internship');
        $topicRepo = $manager->getRepository('App:Topic');

        $intern = $internRepo->find($id);
        $user =$intern->getUser();
        $internship= $internshipRepo->findOneBy(['intern' => $id]);
        $topic = $topicRepo->find($internship->getTopic());
        //dump($topic);exit;

        $internn = new Intern();
        $form = $this->createForm(InternFormType::class, $internn);
        $form->handleRequest($request);
        if ($form->isSubmitted()) { 
           // 
            $internData = $form->getData();
            $newInternship[] = $internData->getInternships();
            $newUser = $internData->getUser();
            
            //contruct User infos 
            $intern->setSchool($internData->getSchool());
            $intern->setCountry($internData->getCountry());
            $intern->setCity($internData->getCity());
            $intern->setFormation($internData->getFormation());
            $intern->setSpeciality($internData->getSpeciality());
            $intern->setLevel($internData->getLevel());
            $intern->setCv($internData->getCv());

            $intern->setBirthday($internData->getBirthday());

            $user->setFirstName($newUser->getFirstName());
            $user->setLastName($newUser->getLastName());
            $user->setAdresse($newUser->getAdresse());
            $user->setEmail($newUser->getEmail());
            $user->setPhone($newUser->getPhone());
            //photo
            if($newUser->getPhoto()){
                $file = $newUser->getPhoto();
                $fileName = md5(uniqid()).'.'.$file->guessExtension();
                $file->move(
                    $this->getParameter('photos_directory'),
                    $fileName
                );
                $user->setPhoto($fileName);
            }
            $user->setNic($newUser->getNic());
            $user->setUpdatedAt(new \DateTime());
            $intern->setUser($user);
            //internship
            $internshipp = (object)$newInternship[0]["__name__"];
            $internship->setUpdatedAt(new \DateTime());
            $internship->setIntern($intern);
            $internship->setTopic($internshipp->getTopic());
            $internship->setDuration($internshipp->getDuration());
            // flush DB
            $manager->flush();   

            return $this->redirectToRoute('stagiaire_liste');
        }
        return $this->render('g_stagiaires/admin_stagiaire_modifier.html.twig',array(
                'InternForm' => $form->createView(),
                'intern' => $intern,
                'user' => $user,
                'internship' => $internship,
                'topic' => $topic
            )
        );

    }
     /**
     * @Route("st-imalia/stagiaire/details/{id}", name="stagiaire_details")
     */
    public function stagiaire_details($id)
    {
       $manager = $this->getDoctrine()->getManager();
       //repos
       //eneityRepo
       $InternRepo=  $manager->getRepository('App:Intern');
       $UserRepo=  $manager->getRepository('App:User'); 
       $InternshipRepo=  $manager->getRepository('App:Internship');
       $TopicRepo=  $manager->getRepository('App:Topic');

       $intern= $InternRepo->find($id);
       $user=$UserRepo->find($intern->getUser());
       $internship= $InternshipRepo-> findOneBy(['intern' => $id]);
       $topic=$TopicRepo->find($internship->getTopic());
       return $this->render('g_stagiaires/admin_stagiaire_details.html.twig',array('intern' => $intern,'user' => $user,'internship' => $internship,'topic' => $topic));
    }
     /**
    * @Route("st-imalia/intern/archive/details/{id}", name="stagiaire_archive_details")
     */
    public function stagiaire_archive_details($id)
    {
       $manager = $this->getDoctrine()->getManager();
       //repos
       //eneityRepo
       $InternRepo=  $manager->getRepository('App:Intern');
       $UserRepo=  $manager->getRepository('App:User'); 
       $InternshipRepo=  $manager->getRepository('App:Internship');
       $TopicRepo=  $manager->getRepository('App:Topic');
       

       $intern= $InternRepo->find($id);
       $user=$UserRepo->find($intern->getUser());
       $internship= $InternshipRepo-> findOneBy(['intern' => $id]);
       $topic=$TopicRepo->find($internship->getTopic());
       return $this->render('g_stagiaires/admin_stagiaire_archive_details.html.twig',array('intern' => $intern,'user' => $user,'internship' => $internship,'topic' => $topic));
    }
    /**
     * @Route("st-imalia/intern/archive/list", name="stagiaire_archive")
     */
    public function stagiaires_archive_liste(PaginatorInterface $paginator, Request $request)
    {
       $manager = $this->getDoctrine()->getManager();
       //repos
       //eneityRepo
       $InternRepo=  $manager->getRepository('App:Intern');

       $users = array();
       $message="";
       $form = $this->createFormBuilder(null)
                     ->add('input') 
                     ->add('rechercher', SubmitType::class)
                     ->getForm();

       $form->handleRequest($request); 
            
       if($form->isSubmitted()){
            $data = $form->getData();  
            //dump($data['input']);exit;
            $mot = $data['input'];
            $users = $paginator->paginate(
                                    $InternRepo->searchResultsArchive($mot),
                                    $request->query->getInt('page',1),
                                    16
                                     );

            if ($users==NULL) {
                $message="Aucun résultat n'a été trouvé !!";
            }

            //dump($resultats);exit;
        }
        else{
            //$paginator  = $this->get('knp_paginator');
            $users = $paginator->paginate(
                                    $InternRepo->myFindListArchive(),
                                    $request->query->getInt('page',1),
                                    16
                                     );
           
        }

                return $this->render('g_stagiaires/admin_archive_liste_stagiaires.html.twig',
        array('users' => $users,
              'SearchForm' => $form->createView(),
              'message' => $message));
      
    }

    /**
     * @Route("st-imalia/intern/archive/desactiver/{id}", name="stagiaire_desactiver_archive")
     */

    public function stagiaire_reactiver_archive($id)
   {    
        $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
        $UserRepo=  $manager->getRepository('App:User');

        $users = $UserRepo->reactivateUser($id);

     return $this->redirectToRoute('stagiaire_archive', array('users' => $users));
     
    }
    
    /**
     * @Route("st-imalia/stagiaire/contact", name="stagiaire_contacter")
     */
    public function stagiaire_contacter()
    {
        return $this->render('g_stagiaires/Admin_ContacterStagiaire.html.twig', [
            'controller_name' => 'GStagiairesController',
        ]);
    }
    /**
     * @Route("st-imalia/intern/list/telechargerListeStagiaires", name="telechargerListeStagiaires")
     */
    public function download_list_stagiaires()
    {
         $manager = $this->getDoctrine()->getManager();
         //repos
         //eneityRepo
         $InternRepo=  $manager->getRepository('App:Intern');
         $users = $InternRepo->myFindAllStagiaires();
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_stagiaires/TelechargerListeStagiaires.html.twig', [
            'users' => $users
        ]);
        
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listStagiaires.pdf", [
            "Attachment" => false
        ]);
    }
    /**
     * @Route("st-imalia/intern/list/telechargerListeStagiairesArchive", name="telechargerListeStagiairesArchive")
     */
    public function download_list_archive_stagiaires()
    {
         $manager = $this->getDoctrine()->getManager();
         //repos
         //eneityRepo
         $InternRepo=  $manager->getRepository('App:Intern');
         $users = $InternRepo->myFindAllStagiairesArchive();
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_stagiaires/TelechargerListeStagiaires.html.twig', [
            'users' => $users
        ]);
        
        
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listStagiaires.pdf", [
            "Attachment" => false
        ]);
    }
     


}