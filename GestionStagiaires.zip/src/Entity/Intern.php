<?php

namespace App\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\InternRepository")
 */
class Intern
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $school;

    /**
     * @ORM\Column(type="string", length=25)
     */
    private $country;

    /**
     * @ORM\Column(type="string", length=25)
     */
    private $city;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $formation;

    /**
     * @ORM\Column(type="string", length=100)
     */
    private $speciality;

    /**
     * @ORM\Column(type="string", length=25)
     */
    private $level;

    
     /**
     * @ORM\OneToOne(targetEntity="User",cascade={"persist"},fetch="EAGER")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id" )
     */



    protected $user;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $cv;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Internship", mappedBy="intern")
     */
    private $internships;

    /**
     * @ORM\Column(type="date")
     */
    private $birthday;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\Absence", mappedBy="intern")
     */
    private $absences;

    /**
     * @ORM\OneToMany(targetEntity="App\Entity\AbsencePermission", mappedBy="intern")
     */
    private $absencePermissions;

    /**
     * @ORM\ManyToMany(targetEntity="App\Entity\Task", mappedBy="intern")
     */
    private $tasks;

 
    public function __construct()
    {
        $this->internships = new ArrayCollection();
        $this->absences = new ArrayCollection();
        $this->absencePermissions = new ArrayCollection();
        $this->tasks = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getSchool(): ?string
    {
        return $this->school;
    }

    public function setSchool(string $school): self
    {
        $this->school = $school;

        return $this;
    }

    public function getCountry(): ?string
    {
        return $this->country;
    }

    public function setCountry(string $country): self
    {
        $this->country = $country;

        return $this;
    }

    public function getCity(): ?string
    {
        return $this->city;
    }

    public function setCity(string $city): self
    {
        $this->city = $city;

        return $this;
    }

    public function getFormation(): ?string
    {
        return $this->formation;
    }

    public function setFormation(string $formation): self
    {
        $this->formation = $formation;

        return $this;
    }

    public function getSpeciality(): ?string
    {
        return $this->speciality;
    }

    public function setSpeciality(string $speciality): self
    {
        $this->speciality = $speciality;

        return $this;
    }

    public function getLevel(): ?string
    {
        return $this->level;
    }

    public function setLevel(string $level): self
    {
        $this->level = $level;

        return $this;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(User $user): self
    {
        $this->user = $user;

        return $this;
    }

    public function getCv()
    {
        return $this->cv;
    }

    public function setCv($cv)
    {
        $this->cv = $cv;

        return $this;
    }

    /**
     * @return Collection|Internship[]
     */
    public function getInternships(): Collection
    {
        return $this->internships;
    }

    public function getBirthday(): ?\DateTimeInterface
    {
        return $this->birthday;
    }

    public function setBirthday(\DateTimeInterface $birthday): self
    {
        $this->birthday = $birthday;

        return $this;
    }
    public function __toString()
    {
        return "somthing";
    }
    /**
    *
    *@param \App\Entity\Internship $internship
    *
    *@return Intern
    *
    */
    public function addInternship(\App\Entity\Internship $internship)
    {
        $this->internships[]=$internship;
        $internship->setIntern($this);
        return $this;
    }

    /**
     * @return Collection|Absence[]
     */
    public function getAbsences(): Collection
    {
        return $this->absences;
    }

    public function addAbsence(Absence $absence): self
    {
        if (!$this->absences->contains($absence)) {
            $this->absences[] = $absence;
            $absence->setIntern($this);
        }

        return $this;
    }

    public function removeAbsence(Absence $absence): self
    {
        if ($this->absences->contains($absence)) {
            $this->absences->removeElement($absence);
            // set the owning side to null (unless already changed)
            if ($absence->getIntern() === $this) {
                $absence->setIntern(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|AbsencePermission[]
     */
    public function getAbsencePermissions(): Collection
    {
        return $this->absencePermissions;
    }

    public function addAbsencePermission(AbsencePermission $absencePermission): self
    {
        if (!$this->absencePermissions->contains($absencePermission)) {
            $this->absencePermissions[] = $absencePermission;
            $absencePermission->setIntern($this);
        }

        return $this;
    }

    public function removeAbsencePermission(AbsencePermission $absencePermission): self
    {
        if ($this->absencePermissions->contains($absencePermission)) {
            $this->absencePermissions->removeElement($absencePermission);
            // set the owning side to null (unless already changed)
            if ($absencePermission->getIntern() === $this) {
                $absencePermission->setIntern(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection|Task[]
     */
    public function getTasks(): Collection
    {
        return $this->tasks;
    }

    public function addTask(Task $task): self
    {
        if (!$this->tasks->contains($task)) {
            $this->tasks[] = $task;
            $task->addIntern($this);
        }

        return $this;
    }

    public function removeTask(Task $task): self
    {
        if ($this->tasks->contains($task)) {
            $this->tasks->removeElement($task);
            $task->removeIntern($this);
        }

        return $this;
    }





   
}
