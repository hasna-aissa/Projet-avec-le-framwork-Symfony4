<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Supervisor;
use App\Entity\Topic;
use Symfony\Component\Form\FormView;
use App\Repository\SupervisorRepository;
use App\Repository\TopicRepository;
use App\Form\TopicFormType;
use App\Form\SupervisorFormType;

use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Knp\Component\Pager\PaginatorInterface; 
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\HttpFoundation\JsonResponse;

class GSujetsController extends AbstractController
{
    /**
     * @Route("/g/sujets", name="g_sujets")
     */
    public function index()
    {
        return $this->render('g_sujets/index.html.twig', [
            'controller_name' => 'GSujetsController',
        ]);
    }
    /**
     * @Route("st-imalia/Topic/list", name="liste_sujet_admin")
     */
    public function liste_sujet_admin(Request $request, ObjectManager $manager,PaginatorInterface $paginator)
    {
            if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
   { 
        $manager=$this->getDoctrine()->getManager();
        $topicRepository= $manager->getRepository('App:Topic'); 
        $mot = $request->request->get('search');
        $topics=$topicRepository->searchResultsTopic($mot);
        $jsonData = array();
        $idx = 0;  
        foreach($topics as $topic) {  
            $temp = array(
               'title' => $topic['title'],  
               'id' => $topic['id']
            );   
        $jsonData[$idx++] = $temp;  
      } 
      return new JsonResponse($jsonData); 
   } 
        $manager=$this->getDoctrine()->getManager();
        $topicRepository=$manager->getRepository('App:Topic');
       //liste et la recherche 
       $topics = array();
       $message="";

            //pagination
            $topics = $paginator->paginate($topicRepository->myFindAllTopic(),
                                    $request->query->getInt('page',1,2),
                                    16
                                     );
        return $this->render('g_sujets/liste_sujet_admin.html.twig', array(
                'message' => $message,
                'topics' => $topics,
            )
        );
       
    }

    /**
     * @Route("st-imalia/Topic/list", name="liste_sujet")
     */
    public function liste_sujet()
    {
        return $this->render('g_sujets/encadrant_liste_sujet.html.twig'
        );
    }


    /**
     * @Route("st-imalia/Topic/add", name="ajouter_sujet")
     */
    public function ajouter_sujet(Request $request, ObjectManager $manager)
    {
        $topic = new Topic();
        $form = $this->createForm(TopicFormType::class, $topic);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();

            //isActive
            $topic->setState('NC') ;

            //document
      
               $fileIntern = $topic->getDocument();
            $fileNameIntern = md5(uniqid()).'.'.$fileIntern->guessExtension();
            $fileIntern->move(
                $this->getParameter('documentTopic_directory'),
                $fileNameIntern
            );
            $topic->setDocument($fileNameIntern);
            
            //CreatedAt  
            $topic->setCreatedAt(new \DateTime());
          
            // Persist user
            $manager->persist($topic); 
            
            // flush DB
            $manager->flush();
            return $this->redirectToRoute('liste_sujet_admin');
        }
        return $this->render('g_sujets/ajouter_sujet.html.twig', array(
                'TopicForm' => $form->createView())
        );
    }

    /**
     * @Route("st-imalia/sujets/avancement", name="sujet_avancement")
     */
    public function sujet_avancement()
    {
        return $this->render('g_sujets/encadrant_sujet_avancement.html.twig', [
            'controller_name' => 'GSujetsController',
        ]);
    }

    /**
     * @Route("st-imalia/sujet/tache/details", name="tache_details")
     */
    public function tache_details()
    {
        return $this->render('g_sujets/encadrant_sujet_tache_details.html.twig', [
            'controller_name' => 'GSujetsController',
        ]);
    }

    /**
     * @Route("st-imalia/Topic/details/{id}", name="details_sujet")
     */
    public function details_sujet($id)
    {
        $topic = new Topic();
        $topicRepository=$this->getDoctrine()->getRepository(Topic::class);
        $topic=$topicRepository->find($id);
        $supervisor=$topic->getSupervisor();
        $user=$supervisor->getUser();
        $internship=$topic->getInternship();
        //dump($internship);exit;
        //$intern=$internship->getIntern();
        
        return $this->render('g_sujets/details_sujet_admin.html.twig',array('topic' => $topic,'supervisor' => $supervisor,'user' => $user));
    }

    /**
     * @Route("st-imalia/Topic/edit/{id}", name="modifier_sujet")
     */
    public function modifier_sujet($id,Request $request, ObjectManager $manager)
    {
        $topic = new Topic();
        $topicRepository=$this->getDoctrine()->getRepository(Topic::class);
        $topic=$topicRepository->find($id);
        $supervisor=$topic->getSupervisor();
        $form = $this->createForm(TopicFormType::class, $topic);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();
            //document
           
             //document
      
               $fileIntern = $topic->getDocument();
            $fileNameIntern = md5(uniqid()).'.'.$fileIntern->guessExtension();
            $fileIntern->move(
                $this->getParameter('documentTopic_directory'),
                $fileNameIntern
            );
            $topic->setDocument($fileNameIntern);
            
            //CreatedAt  
            $topic->setUpdatedAt(new \DateTime());
            
            // flush DB
            $manager->flush();
            return $this->redirectToRoute('liste_sujet_admin');
        }
        return $this->render('g_sujets/modifier_sujet_admin.html.twig',array('TopicForm' => $form->createView()));
    }
    
    /**
     * @Route("st-imalia/Topic/delete/{id}", name="supprimer_sujet")
     */
    public function supprimer_sujet(Request $request, ObjectManager $manager,$id)
    {
    if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
    { 
        $manager=$this->getDoctrine()->getManager();
        $topicRepository=$manager->getRepository('App:Topic');
        $id=$request->request->get('idTopic');

        //la verification si le sujet est deja affecté 
        $topic=$this->getDoctrine()->getRepository(Topic::class)->find($id);
        $result=$topicRepository->ResultIsAffect($id);
        $count=$result[0]['affect'];
        if ($count==0) {
            $manager->remove($topic);
            $manager->flush();
        }
        else {

        } 
      } 
      $manager=$this->getDoctrine()->getManager();
        $topicRepository=$manager->getRepository('App:Topic');

        //la verification si le sujet est deja affecté 
        $topic=$this->getDoctrine()->getRepository(Topic::class)->find($id);
        $result=$topicRepository->ResultIsAffect($id);
        $count=$result[0]['affect'];
        if ($count==0) {
            $manager->remove($topic);
            $manager->flush();
        }
        else {

        } 
  
        return $this->redirectToRoute('liste_sujet_admin', array('result' => $result));
    }



    /**
     * @Route("st-imalia/Topic/list/telechargerListeSujets", name="telechargerListeSujets")
     */
    public function download_list_sujet()
    {
        $topicRepository= $this ->getDoctrine()->getManager()->getRepository('App:Topic');
         $topics =$topicRepository->myFindAllTopic();
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_sujets/telechargerListeSujets.html.twig', [
            'topics' => $topics
        ]);
        
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listSujets.pdf", [
            "Attachment" => false
        ]);
    }
}
