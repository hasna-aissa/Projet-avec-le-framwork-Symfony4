<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use App\Form\TaskFormType;
use App\Entity\Task;
use App\Entity\Topic;
use App\Entity\Intern;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use App\Repository\TaskRepository;
use Knp\Component\Pager\PaginatorInterface; 
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\HttpFoundation\JsonResponse;

class GTaskController extends AbstractController
{
     /**
     * @Route("/st-imalia/task/add", name="g_task")
     */
    public function AjouterTask(Request $request, ObjectManager $manager)
    {
    	$task = new Task();
      //$topic = new Topic();
        $form = $this->createForm(TaskFormType::class, $task);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;
            $manager = $this->getDoctrine()->getManager();
           // $id=$task->getId();
            $title=$task->getTitle();
            //$intern=$task->getIntern();
            $desc=$task->getDescription();
            $startD=$task->getStartDate();
            $estimationSup=$task->getEstimationSupervisor();
            //$topictask=$topic->getTasks();
            
            //isActive
            $task->setState('NC') ;
            $task->setTitle($title);
            $task->setDescription($desc);
            $task->setStartDate($startD);
            $task->setEstimationSupervisor($estimationSup);
            //$task->addIntern($intern);
            
           //CreatedAt  
            $task->setCreatedAt(new \DateTime());
             //$topic->addTask($topictask);
          
            // Persist user
            $manager->persist($task); 
            
            // flush DB
            $manager->flush();
            return $this->redirectToRoute('listTasks');
        }
        return $this->render('g_task/AjouterTask.html.twig',array(
                'TaskForm' => $form->createView()));
    }

    /**
     * @Route("st-imalia/Task/list", name="listTasks")
     */
    public function liste_task(Request $request, ObjectManager $manager,PaginatorInterface $paginator)
    {
            if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
   { 
        $manager=$this->getDoctrine()->getManager();
        $topicRepository= $manager->getRepository('App:Task'); 
        $mot = $request->request->get('search');
        $topics=$topicRepository->searchResultsTask($mot);
        $jsonData = array();
        $idx = 0;  
        foreach($topics as $topic) {  
            $temp = array(
               'title' => $topic['title'],  
               'id' => $topic['id']
            );   
        $jsonData[$idx++] = $temp;  
      } 
      return new JsonResponse($jsonData); 
   } 
        $manager=$this->getDoctrine()->getManager();
        $topicRepository=$manager->getRepository('App:Task');
       //liste et la recherche 
       $topics = array();
       $message="";

            //pagination
            $topics = $paginator->paginate($topicRepository->myFindAllTask(),
                                    $request->query->getInt('page',1,2),
                                    16
                                     );
        return $this->render('g_task/ListTasks.html.twig', array(
                'message' => $message,
                'topics' => $topics,
            )
        );
       
    }
    /**
     * @Route("st-imalia/Task/edit/{id}", name="modifier_task")
     */
    public function modifier_task($id,Request $request, ObjectManager $manager)
    {
        $topic = new Task();
        $topicRepository=$this->getDoctrine()->getRepository(Task::class);
        $topic=$topicRepository->find($id);
        $form = $this->createForm(TaskFormType::class, $topic);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();
          
           
             
            //CreatedAt  
            $topic->setUpdatedAt(new \DateTime());
            
            // flush DB
            $manager->flush();
            return $this->redirectToRoute('listTasks');
        }
        return $this->render('g_task/modifier_task.html.twig',array('TaskForm' => $form->createView()));
    }
    
    /**
     * @Route("st-imalia/Task/details/{id}", name="details_task")
     */
    public function details_task($id)
    {
        $topic = new Task();
        $topicRepository=$this->getDoctrine()->getRepository(Task::class);
        $topic=$topicRepository->find($id);
        //dump($topic);exit;
        //$intern=$internship->getIntern();
        
        return $this->render('g_task/details_task.html.twig',array('topic' => $topic));
    }

}
