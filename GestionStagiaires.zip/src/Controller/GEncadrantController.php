<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Supervisor;
use App\Entity\user;
use App\Entity\Intern;
use App\Repository\InternRepository;
use Symfony\Component\Form\FormView;
use App\Repository\SupervisorRepository;
use App\Form\UserFormType;
use App\Form\SupervisorFormType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Knp\Component\Pager\PaginatorInterface; 
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class GEncadrantController extends AbstractController
{
    /**
     * @Route("st-imalia/Supervisor/add", name="ajouter_encadrant")
     */
    public function ajouter_encadrant(Request $request, ObjectManager $manager,UserPasswordEncoderInterface $encoder)
    {
        $supervisor = new Supervisor();
        $supervisorRepository=$this->getDoctrine()->getRepository(Supervisor::class);
        $form = $this->createForm(SupervisorFormType::class, $supervisor);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();

            //contruct User infos 
            $user =$supervisor->getUser();

            //username   
            $first=substr($user->getLastName(),0, 1);
            $last=substr($user->getFirstName(),0, 2);
            $UserName=strtoupper($first.$last);
            $user->setUserName($UserName);

            //isActive
            $user->setIsActive(true) ;

            //password
            //password
            $password=$user->getLastName();
            $user->setPassword($password);

            //photo
          $file = $user->getPhoto();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move(
                $this->getParameter('photos_directory'),
                $fileName
            );
            $user->setPhoto($fileName);
            
            //CreatedAt  
            $user->setCreatedAt(new \DateTime());
          


            //persist user   
             $hash= $encoder->encodePassword($user,$user->getPassword());
             $user->setPassword($hash);
             $manager->persist($user);
          
            // Persist Intern
            $manager->persist($supervisor); 


            // flush DB
            $manager->flush();   

            return $this->redirectToRoute('encadrants_liste');
        }
        return $this->render('g_encadrant/ajouter_encadrant.html.twig', array(
                'SupervisorForm' => $form->createView()
            )
        );
    }

    /**
     * @Route("st-imalia/Supervisor/edit/{id}", name="modifier_encadrant")
     */
    public function modifier_encadrant(Request $request, ObjectManager $manager,$id)
    {
        $supervisor = new Supervisor();
        $supervisorRepository=$this->getDoctrine()->getRepository(Supervisor::class);
        $supervisor=$supervisorRepository->find($id);
        $user=$supervisor->getUser();
        $form = $this->createForm(SupervisorFormType::class, $supervisor);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();
            
            //CreatedAt  
            $user->setUpdatedAt(new \DateTime());

            //username 
             $first=substr($user->getLastName(),0, 1);
            $last=substr($user->getFirstName(),0, 2);
            $UserName=strtoupper($first.$last);
            $user->setUserName($UserName);

            //photo
              //photo
          $file = $user->getPhoto();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move(
                $this->getParameter('photos_directory'),
                $fileName
            );
            $user->setPhoto($fileName);
            // flush DB
            $manager->flush();   

            return $this->redirectToRoute('encadrants_liste');
        }
        return $this->render('g_encadrant/edit_encadrant.html.twig', array(
                'SupervisorForm' => $form->createView()
            )
        );
    }

    /**
     * @Route("/g/encadrant", name="g_encadrant")
     */
    public function index()
    {
        return $this->render('g_encadrant/index.html.twig', [
            'controller_name' => 'GEncadrantController',
        ]);
    }


     /**
     * @Route("st-imalia/Supervisor/list", name="encadrants_liste")
     */
    public function encadrants_liste(Request $request, ObjectManager $manager,PaginatorInterface $paginator)
    {
    	if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
   { 
   		$manager=$this->getDoctrine()->getManager();
    	$supervisorRepository= $manager->getRepository('App:Supervisor'); 
   		$t1 = $request->request->get('search');
   		$supervisors=$supervisorRepository->SearchSupervisors($t1,1);
	    $jsonData = array();
	    $idx = 0;  
	    foreach($supervisors as $supervisor) {  
	        $temp = array(
	           'lastName' => $supervisor['lastName'],  
	           'firstName' => $supervisor['firstName'], 
	           'service' => $supervisor['service'],
	           'photo' => $supervisor['photo'],
	           'id' => $supervisor['id'],
	           'idUser' =>$supervisor['idUser']
	        );   
        $jsonData[$idx++] = $temp;  
      } 
      return new JsonResponse($jsonData); 
   } 


    	$manager=$this->getDoctrine()->getManager();
    	$supervisorRepository=$manager->getRepository('App:Supervisor');
       	//liste et la recherche 
       	$supervisors = array();
       	$message="";
            $supervisors = $paginator->paginate($supervisorRepository->myFindAllEncadrant(1),
                                    $request->query->getInt('page',1,2),
                                    16
                                     );
        return $this->render('g_encadrant/liste_encadrant.html.twig', array(
              	'message' => $message,
              	'supervisors' => $supervisors,
            )
        );
       
    }

    /**
     *@Route("st-imalia/Supervisor/desactiver/{id}", name="supervisor_desactiver")
     */

    public function supervisor_desactiver($id)
    { 
    	$manager=$this->getDoctrine()->getManager();
    	$userRepository= $manager->getRepository('App:User');
        $supervisors =$userRepository->desactivateUser($id);

     return $this->redirectToRoute('encadrants_liste', array('supervisors' => $supervisors));
     
    }


    /**
     *@Route("st-imalia/Supervisor/details/{id}", name="Supervisor_details")
     */

    public function Supervisor_details($id)
    { 
    	$supervisor=$this->getDoctrine()->getRepository(Supervisor::class)->find($id);
    	$user=$supervisor->getUser();

    	//liste des stagiaires encadrés
    	$manager=$this->getDoctrine()->getManager();
    	$supervisorRepository= $manager->getRepository('App:Supervisor');
    	$interns=$supervisorRepository->GetInternsOfSupervisor($id);
    	
    	$topic=$supervisorRepository->listOfTopic($id);


     	return $this->render('g_encadrant/details_encadrant.html.twig',
     		array('supervisor' => $supervisor,'user' => $user,'interns'=> $interns,'topic' => $topic
 		));
    }




     /**
     * @Route("st-imalia/Supervisor/list_desactive", name="encadrants_list_desactive")
     */
    public function encadrants_list_desactive(Request $request, ObjectManager $manager,PaginatorInterface $paginator)
    {
    	$manager=$this->getDoctrine()->getManager();
    	$supervisorRepository=$manager->getRepository('App:Supervisor');
    	//recherche

    	if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
   { 
   		$manager=$this->getDoctrine()->getManager();
    	$supervisorRepository= $manager->getRepository('App:Supervisor'); 
   		$mot = $request->request->get('search');
   		$supervisors=$supervisorRepository->SearchSupervisors($mot,0);
	    $jsonData = array();
	    $idx = 0;  
	    foreach($supervisors as $supervisor) {  
	        $temp = array(
	           'lastName' => $supervisor['lastName'],  
	           'firstName' => $supervisor['firstName'], 
	           'service' => $supervisor['service'],
	           'photo' => $supervisor['photo'],
	           'id' => $supervisor['id'],
	           'idUser' =>$supervisor['idUser']
	        );   
        $jsonData[$idx++] = $temp;  
      } 
      return new JsonResponse($jsonData);  
  }
    	//Liste des encadrants
        $supervisors = array();
        $supervisors = $paginator->paginate($supervisorRepository->myFindAllEncadrant(0),$request->query->getInt('page',1,2),16);
        
        return $this->render('g_encadrant/liste_encadrant_desactive.html.twig', array(
              	'supervisors' => $supervisors,
            )
        );
}

    /**
     * @Route("st-imalia/Supervisor_deasctivé/reactiver/{id}", name="encadrant_reactiver")
     */

    public function encadrant_reactiver($id)
   { 
   		$manager=$this->getDoctrine()->getManager();
   		$userRepository=$manager->getRepository('App:User');
        $users = $userRepository->reactivateUser($id);

     return $this->redirectToRoute('encadrants_list_desactive', array('users' => $users));
     
    }

    /**
     * @Route("st-imalia/intern/list/telechargerListeEncadrants", name="telechargerListeEncadrants")
     */
    public function download_list_encadrant()
    {
    	$userRepository= $this ->getDoctrine()->getManager()->getRepository('App:User');
         $users =$userRepository->myFindAllEncadrant(1);
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_encadrant/telechargerListeEncadrants.html.twig', [
            'users' => $users
        ]);
        
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listEncadrants.pdf", [
            "Attachment" => false
        ]);
    }


    /**
     * @Route("st-imalia/intern/list/telechargerListeEncadrantsDesactive", name="telechargerListeEncadrantsDesactive")
     */
    public function download_list_encadrant_desactive()
    {
        $userRepository= $this ->getDoctrine()->getManager()->getRepository('App:User');
        $users =$userRepository->myFindAllEncadrant(0);
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_encadrant/telechargerListeEncadrants.html.twig', [
            'users' => $users
        ]);
        
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listEncadrants.pdf", [
            "Attachment" => false
        ]);
    }


	/**
     * @Route("st-imalia/Supervisor/ajax", name="ajax")
     */
public function ajaxAction(Request $request,ObjectManager $manager) {  
   if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
   { 
   		$manager=$this->getDoctrine()->getManager();
    	$supervisorRepository= $manager->getRepository('App:Supervisor'); 
   		$t1 = $request->request->get('search');
   		$supervisors=$supervisorRepository->SearchSupervisors($t1,1);
	    $jsonData = array();
	    $idx = 0;  
	    foreach($supervisors as $supervisor) {  
	        $temp = array(
	           'service' => $supervisor['lastName'],  
	           'city' => $supervisor['firstName'],  
	        );   
        $jsonData[$idx++] = $temp;  
      } 
      return new JsonResponse($jsonData); 
   } else { 
      return $this->render('g_encadrant/testAjax.html.twig'); 
   } 
} 
    

}
