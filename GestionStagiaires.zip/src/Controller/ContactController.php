<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Message;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Supervisor;
use App\Entity\user;
use App\Entity\Intern;
use App\Repository\InternRepository;
use Symfony\Component\Form\FormView;
use App\Repository\SupervisorRepository;
use App\Form\UserFormType;
use App\Form\SupervisorFormType;
use App\GlobaleServices\FichierConvert;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Knp\Component\Pager\PaginatorInterface; 
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\HttpFoundation\JsonResponse;

class ContactController extends AbstractController
{
    /**
     * @Route("/contact", name="contact")
     */
    public function ListStagiaires()
    {   
       $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
       $MessageRepo=  $manager->getRepository('App:Message');

    	$users=$MessageRepo->myFindListContact();

    	$MessageRepo=  $manager->getRepository('App:Message');
        $userCurrent = $this->getUser();
     
        $id=$userCurrent->getId();
        $intern =$this->getDoctrine()->getRepository(Intern::class)->findOneBy(['user' => $id]);
    	$messages=$MessageRepo->myFindMessages($intern->getId());
        return $this->render('contact/admin_contacterStagiaires.html.twig',array('users'=>$users,'messages'=>$messages));
    }


     /**
     * @Route("st-imalia/Supervisor/ajax", name="ajax")
     */
public function ajaxAction(Request $request,ObjectManager $manager) {  
   if ($request->isXmlHttpRequest()|| $request->query->get('showJson') == 1)
   { 
         $manager=$this->getDoctrine()->getManager();
      $supervisorRepository= $manager->getRepository('App:Supervisor'); 
         $t1 = $request->request->get('search');
         $supervisors=$supervisorRepository->SearchSupervisors2($t1);
       $jsonData = array();
       $idx = 0;  
       foreach($supervisors as $supervisor) {  
           $temp = array(
              'messageContent' => $supervisor['messageContent'],  
              'user' => $supervisor['user'],  
           );   
        $jsonData[$idx++] = $temp;  
      } 
      return new JsonResponse($jsonData); 
   } else { 
      return $this->render('contact/testAjax.html.twig'); 
   } 
} 
}
