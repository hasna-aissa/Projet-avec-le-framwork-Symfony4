<?php

namespace App\Repository;

use App\Entity\Intern;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method Intern|null find($id, $lockMode = null, $lockVersion = null)
 * @method Intern|null findOneBy(array $criteria, array $orderBy = null)
 * @method Intern[]    findAll()
 * @method Intern[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class InternRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Intern::class);
    }

   /**
      * @return Query
      */
     public function myFindAll()
     {
    return $this->findAllQuery()
                ->getQuery();
    }

    private function findAllQuery() 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,i.id,i.school,t.title,s.startDate,s.duration,u.id AS idUser')
                  ->from('App:User', 'u')   
                  ->join('App:Intern' ,'i')
                  ->join('App:Internship','s')
                  ->join('App:Topic','t')
                  ->where('u.id=i.user')
                  ->andWhere('s.intern=i.id')
                  ->andWhere('s.topic=t.id')
                  ->andWhere('u.isActive=1');
    }
    /**
      * @return Query
      */
    public function searchResults($cle)
    {
        return $this->search($cle)
                    ->getQuery();
    }
    
     private function search($cle) 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,i.id,u.id AS idUser')
                  ->from('App:User', 'u')   
                  ->join('App:Intern' ,'i')
                  ->where('u.id=i.user')
                  ->andWhere("u.firstName LIKE '%".$cle."%' OR u.lastName LIKE '%".$cle."%'")
                  ->andWhere('u.isActive=1');
    }
       public function  myFindListArchive() {
    return $this->_em->createQuery('
        SELECT u.firstName,u.lastName,u.photo,i.id,i.school,t.title,s.startDate,s.duration,u.id AS idUser
        FROM App:User u,App:Intern i,App:Internship s,App:Topic t
        WHERE u.isActive=0 AND u.id=i.user AND s.intern=i.id AND s.topic=t.id  
    ')->getResult();
    }

    /**
      * @return Query
      */
    public function searchResultsArchive($cle)
    {
        return $this->searchArchive($cle)
                    ->getQuery();
    }
    
     private function searchArchive($cle) 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,i.id,u.id AS idUser')
                  ->from('App:User', 'u')   
                  ->join('App:Intern' ,'i')
                  ->where('u.id=i.user')
                  ->andWhere("u.firstName LIKE '%".$cle."%' OR u.lastName LIKE '%".$cle."%'")
                  ->andWhere('u.isActive=0');
    }
    // pour le telechargement
    public function myFindAllStagiaires() {
    return $this->_em->createQuery('
        SELECT u.firstName,u.lastName,u.photo,i.id,i.school,t.title,s.startDate,s.duration,u.id AS idUser
        FROM App:User u,App:Intern i,App:Internship s,App:Topic t
        WHERE u.id=i.user AND s.intern=i.id AND s.topic=t.id AND u.isActive=1
    ')->getResult();
    }
        public function myFindAllStagiairesArchive() {
    return $this->_em->createQuery('
        SELECT u.firstName,u.lastName,u.photo,i.id,i.school,t.title,s.startDate,s.duration,u.id AS idUser
        FROM App:User u,App:Intern i,App:Internship s,App:Topic t
        WHERE u.id=i.user AND s.intern=i.id AND s.topic=t.id AND u.isActive=0
    ')->getResult();
    }
  
   

 


    // /**
    //  * @return Intern[] Returns an array of Intern objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('i.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Intern
    {
        return $this->createQueryBuilder('i')
            ->andWhere('i.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}