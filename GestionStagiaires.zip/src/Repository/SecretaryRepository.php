<?php

namespace App\Repository;

use App\Entity\Secretary;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method Secretary|null find($id, $lockMode = null, $lockVersion = null)
 * @method Secretary|null findOneBy(array $criteria, array $orderBy = null)
 * @method Secretary[]    findAll()
 * @method Secretary[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class SecretaryRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Secretary::class);
    }
      /**
      * @return Query
      */
     public function myFindAllSecretaire()
     {
    return $this->findAllQueryS()
                ->getQuery();
    }

    private function findAllQueryS() 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,u.phone,u.nic,u.email,u.adresse,s.country,s.city,s.id,u.id AS idUser')
                  ->from('App:User', 'u')   
                  ->join('App:Secretary' ,'s')
                  ->where('u.id=s.user')
                  ->andWhere('u.isActive=1');
    }

    
    /**
      * @return Query
      */
    public function searchResultsSecretary($cle)
    {
        return $this->searchS($cle)
                    ->getQuery();
    }
    
     private function searchS($cle) 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,s.id AS idSecretary')
                  ->from('App:User', 'u')   
                  ->join('App:Secretary' ,'s')
                  ->where('u.id=s.user')
                  ->andWhere("u.firstName LIKE '%".$cle."%' OR u.lastName LIKE '%".$cle."%'")
                  ->andWhere('u.isActive=1');
    }
     public function myFindAllSecretaireTelecharger() {
    return $this->_em->createQuery('
        SELECT u.firstName,u.lastName,u.nic,u.email,u.adresse,s.country,s.city,s.id AS idSecretary
        FROM App:User u,App:Secretary s
        WHERE u.id=s.user And u.isActive=1
    ')->getResult();
    }




    public function  myFindListArchiveSecretaire() {
    return $this->_em->createQuery('
        SELECT u.firstName,u.lastName,u.photo,u.phone,u.nic,u.email,u.adresse,s.country,s.city,s.id,u.id AS idUser
        FROM App:User u,App:Secretary s
        WHERE u.id=s.user AND u.isActive=0
    ')->getResult();
    }

    /**
      * @return Query
      */
    public function searchResultsArchiveSecretaire($cle)
    {
        return $this->searchArchive($cle)
                    ->getQuery();
    }
    
     private function searchArchive($cle) 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,u.phone,u.nic,u.email,u.adresse,s.country,s.city,s.id,u.id AS idUser')
                  ->from('App:User', 'u')   
                  ->join('App:Secretary' ,'s')
                  ->where('u.id=s.user')
                  ->andWhere("u.firstName LIKE '%".$cle."%' OR u.lastName LIKE '%".$cle."%'")
                  ->andWhere('u.isActive=0');
    }
        public function myFindAllSecretaireDesactivTelecharger() {
    return $this->_em->createQuery('
        SELECT u.firstName,u.lastName,u.nic,u.email,u.adresse,s.country,s.city,s.id AS idSecretary
        FROM App:User u,App:Secretary s
        WHERE u.id=s.user And u.isActive=0
    ')->getResult();
    }
    
 





    // /**
    //  * @return Secretary[] Returns an array of Secretary objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('s.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Secretary
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
