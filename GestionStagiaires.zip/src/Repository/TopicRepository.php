<?php

namespace App\Repository;

use App\Entity\Topic;
use App\Entity\Intern;
use App\Entity\User;
use App\Entity\Internship;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method Topic|null find($id, $lockMode = null, $lockVersion = null)
 * @method Topic|null findOneBy(array $criteria, array $orderBy = null)
 * @method Topic[]    findAll()
 * @method Topic[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class TopicRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Topic::class);
    }


    public function searchResultsTopic($mot)
    {
        return $this->_em->createQuery("SELECT t.title,t.id FROM App:Topic t WHERE t.title LIKE '%".$mot."%'")->getResult();
    }

    public function myFindAllTopic()
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('t.title,t.id')
                  ->from('App:Topic', 't');
    }


    public function ResultIsAffect($id)
    {
        return $this->_em->createQuery("SELECT COUNT(t.id) AS affect FROM App:Topic t,App:Internship i WHERE t.id=i.topic AND t.id='".$id."'")->getResult();
    }

    public function DeleteTopic($id)
    {
        return $this->createQueryBuilder('t')
            ->delete('t.id')
            ->where('t.id = ?1')
            ->setParameter(1, $id)
            ->getQuery()
            ->getSingleScalarResult();
    }
        public function  myFindAllIntern() {
    return $this->_em->createQuery("
        SELECT nt.intern 
        FROM App:Topic t,App:Intern i,App:User u,App:Internship nt
        WHERE  i.id=nt.intern AND u.id=i.user AND t.id=nt.topic
    ")->getResult();
    }
    

    // /**
    //  * @return Topic[] Returns an array of Topic objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('t.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Topic
    {
        return $this->createQueryBuilder('t')
            ->andWhere('t.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
