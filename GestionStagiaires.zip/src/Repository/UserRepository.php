<?php

namespace App\Repository;

use App\Entity\User;
use App\Entity\Intern;
use App\Entity\Secretary;
use App\Entity\Supervisor;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method User|null find($id, $lockMode = null, $lockVersion = null)
 * @method User|null findOneBy(array $criteria, array $orderBy = null)
 * @method User[]    findAll()
 * @method User[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class UserRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, User::class);
    }
        public function desactivateUser($id)
    {
    return $this->createQueryBuilder('u')
            ->update()
            ->set('u.isActive', '0')
            ->where('u.id = ?1')
            ->setParameter(1, $id)
            
            
            ->getQuery()
            ->getSingleScalarResult()
        ;
    }
          public function reactivateUser($id)
    {
    return $this->createQueryBuilder('u')
            ->update()
            ->set('u.isActive', '1')
            ->where('u.id = ?1')
            ->setParameter(1, $id)
            ->getQuery()
            ->getSingleScalarResult()
        ;
    }
    
    public function findIntern($id)
    {
         return $this->_em->createQuery("SELECT COUNT(i.user) as countI  FROM App:User u,App:Intern i WHERE u.id = i.user and u.id='".$id."'")->getResult();
    }
    
    public function findSecretary($id)
    {
         return $this->_em->createQuery("SELECT COUNT(s.user) as countS  FROM App:User u,App:Secretary s WHERE u.id = s.user and u.id='".$id."'")->getResult();
    }
        public function findSupervisor($id)
    {
         return $this->_em->createQuery("SELECT COUNT(s.user) as countSup  FROM App:User u,App:Supervisor s WHERE u.id = s.user and u.id='".$id."'")->getResult();
    }




    
    
        

    



    // /**
    //  * @return User[] Returns an array of User objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('u')
            ->andWhere('u.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('u.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?User
    {
        return $this->createQueryBuilder('u')
            ->andWhere('u.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
