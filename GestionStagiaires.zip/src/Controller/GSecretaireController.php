<?php

namespace App\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;
use Doctrine\Common\Persistence\ObjectManager;
use App\Entity\Secretary;
use App\Entity\user;
use Symfony\Component\Form\FormView;
use App\Repository\SecretaryRepository;
use App\Form\UserFormType;
use App\Form\SecretaryFormType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Knp\Component\Pager\PaginatorInterface; 
use Dompdf\Dompdf;
use Dompdf\Options;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;


class GSecretaireController extends AbstractController
{
    /**
     * @Route("/g/secretaire", name="g_secretaire")
     */
    public function index()
    {
        return $this->render('g_secretaire/index.html.twig', [
            'controller_name' => 'GSecretaireController',
        ]);
    }
        /**
     * @Route("st-imalia/secretary/desactiv/list", name="secretaire_liste_desactive")
     */
    public function secretaire_liste_desactive(Request $request, ObjectManager $manager,PaginatorInterface $paginator)
    {
        //list/?keyword=ahmed
    //request key
        //entity manager 
        $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
       $SecretaryRepo=  $manager->getRepository('App:Secretary');
       $secretary = new Secretary();
        $form = $this->createForm(SecretaryFormType::class, $secretary);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();

            //contruct User infos 
            $user =$secretary->getUser();

            //username   todo : add to Global service 
            $first=substr($user->getLastName(),0, 1);
            $last=substr($user->getFirstName(),0, 2);
            $UserName=strtoupper($first.$last);
            $user->setUserName($UserName);
               //photo
            //start file
            $file = $user->getPhoto();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move(
                $this->getParameter('photos_directory'),
                $fileName
            );

             //password
            $cin=$user->getNic();
            $last=$user->getLastName();
            $password=$last.$cin;
            $user->setPassword($password);

            //isActive
            $user->setIsActive(true) ;       
          
            //CreatedAt  

             $user->setUserName($UserName)
                ->setPassword($password)
                ->setPhoto($fileName)
                ->setCreatedAt(new \DateTime());
          
            // Persist user
            $manager->persist($user); 
            // Persist Intern
            $manager->persist($secretary); 

            // flush DB
            $manager->flush();   

            return $this->redirectToRoute('listSecretaires');
        }

       $secretaires = array();
       $message="";
       

        $formSecretaire = $this->createFormBuilder(null)
                     ->add('input') 
                     ->add('rechercher', SubmitType::class)
                     ->getForm();

        $formSecretaire->handleRequest($request); 
            
        if($formSecretaire->isSubmitted()){
            $data = $formSecretaire->getData();  
            //dump($data['input']);exit;
            $mot = $data['input'];
            $secretaires = $paginator->paginate(
                                    $SecretaryRepo->searchResultsArchiveSecretaire($mot),
                                    $request->query->getInt('page',1),
                                    16
                                     );

            if ($secretaires==NULL) {
                $message="Aucun résultat n'a été trouvé !!";
            }

            //dump($resultats);exit;
        }
        else{
            //$paginator  = $this->get('knp_paginator');
            $secretaires = $paginator->paginate(
                                    $SecretaryRepo->myFindListArchiveSecretaire(),
                                    $request->query->getInt('page',1,2),
                                    16
                                     );
           
        }
        return $this->render('g_secretaire/ListeSecretairesDecativ.html.twig', array(
                'SecretaryForm' => $form->createView(),
              'SearchForm' =>$formSecretaire->createView(),
                'message' => $message,
                'secretaires' => $secretaires,
            )
        );

      
    }
    /**
     * @Route("st-imalia/secretary/list", name="listSecretaires")
     */
    public function listSecretaire(Request $request, ObjectManager $manager,PaginatorInterface $paginator,UserPasswordEncoderInterface $encoder)
    {
         $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
       $SecretaryRepo=  $manager->getRepository('App:Secretary');

    	$secretary = new Secretary();
        $form = $this->createForm(SecretaryFormType::class, $secretary);
        $form->handleRequest($request);
        
        if ($form->isSubmitted()) { 
           // dump($intern);exit;

            $manager = $this->getDoctrine()->getManager();

            //contruct User infos 
            $user =$secretary->getUser();

            //username   todo : add to Global service 
            $first=substr($user->getLastName(),0, 1);
            $last=substr($user->getFirstName(),0, 2);
            $UserName=strtoupper($first.$last);
            $user->setUserName($UserName);
               //photo
            //start file
            $file = $user->getPhoto();
            $fileName = md5(uniqid()).'.'.$file->guessExtension();
            $file->move(
                $this->getParameter('photos_directory'),
                $fileName
            );

           //password  todo : add to Global service 
        
            $password=$user->getLastName();
            $user->setPassword($password);

            //isActive
            $user->setIsActive(true) ;       
          
            //CreatedAt  


             $user->setUserName($UserName)
                ->setPhoto($fileName)
                ->setCreatedAt(new \DateTime());
          
            
             //persist user   
             $hash= $encoder->encodePassword($user,$user->getPassword());
             $user->setPassword($hash);
             $manager->persist($user);

            // Persist Intern
            $manager->persist($secretary); 

            // flush DB
            $manager->flush();   

            return $this->redirectToRoute('listSecretaires');
        }

       $secretaires = array();
       $message="";
       

        $formSecretaire = $this->createFormBuilder(null)
                     ->add('input') 
                     ->add('rechercher', SubmitType::class)
                     ->getForm();

        $formSecretaire->handleRequest($request); 
            
        if($formSecretaire->isSubmitted()){
            $data = $formSecretaire->getData();  
            //dump($data['input']);exit;
            $mot = $data['input'];
            $secretaires = $paginator->paginate(
                                    $SecretaryRepo->searchResultsSecretary($mot),
                                    $request->query->getInt('page',1),
                                    16
                                     );

            if ($secretaires==NULL) {
                $message="Aucun résultat n'a été trouvé !!";
            }

            //dump($resultats);exit;
        }
        else{
            //$paginator  = $this->get('knp_paginator');
            $secretaires = $paginator->paginate(
                                    $SecretaryRepo->myFindAllSecretaire(),
                                    $request->query->getInt('page',1,2),
                                    16
                                     );
           
        }
        return $this->render('g_secretaire/ListeSecretaires.html.twig', array(
                'SecretaryForm' => $form->createView(),
            	'SearchForm' =>$formSecretaire->createView(),
              	'message' => $message,
              	'secretaires' => $secretaires,
            )
        );

    }

        /**
     * @Route("st-imalia/secretary/desactiver/{id}", name="secretaire_desactiver")
     */

    public function secretaire_desactiver($id)
   { 

    $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
       $UserRepo=  $manager->getRepository('App:User');
        $secretaires =$UserRepo->desactivateUser($id);

     return $this->redirectToRoute('listSecretaires', array('secretaires' => $secretaires));
     
    }
     /**
     * @Route("st-imalia/secretary/details/{id}", name="secretaire_details")
     */
    public function secretaire_details($id)
    {

       $secretaires= $this->getDoctrine()->getRepository(Secretary::class)->find($id);

       $user=$secretaires->getUser();
      
       return $this->render('g_secretaire/ListeSecretaires.html.twig',array('secretaires' => $secretaires,'user' => $user));
    }
   
    /**
     * @Route("st-imalia/Secretary/list/telechargerListeStagiaires", name="telechargerListeSecretaire")
     */
    public function download_list_secretaires()
    {
       $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
       $SecretaryRepo=  $manager->getRepository('App:Secretary');

        $users = $SecretaryRepo->myFindAllSecretaireTelecharger();
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_secretaire/TelechargerListeSecretaires.html.twig', [
            'users' => $users
        ]);
        
        
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listSecretaires.pdf", [
            "Attachment" => false
        ]);
    }
     /**
     * @Route("st-imalia/Secretary/list/telechargerListeStagiairesDesactiv", name="telechargerListeSecretaireDesactiv")
     */
    public function download_list_secretaires_desactiv()
    {
        $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
        $SecretaryRepo=  $manager->getRepository('App:Secretary');
         $users =$SecretaryRepo->myFindAllSecretaireDesactivTelecharger();
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');
        
        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);
        
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('g_secretaire/TelechargerListeSecretaires.html.twig', [
            'users' => $users
        ]);
        
        
         // Load HTML to Dompdf
        $dompdf->loadHtml($html);
        
        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();
        // Output the generated PDF to Browser (force download)
        $dompdf->stream("listSecretaires.pdf", [
            "Attachment" => false
        ]);
    }

    
      /**
     * @Route("st-imalia/secretary/archive/reactiver/{id}", name="secretaire_reactiver")
     */

    public function secretaire_reactiver($id)
   { 

         $manager = $this->getDoctrine()->getManager();
        //repos
        //eneityRepo
        $UserRepo=  $manager->getRepository('App:User');
         $secretaires =$UserRepo->reactivateUser($id);

     return $this->redirectToRoute('secretaire_liste_desactive', array('secretaires' => $secretaires));
     
    }
    /**
     * @Route("st-imalia/secretary/edit/{id}", name="secretaire_modifier")
     */
    public function secretaire_modifier(Request $request, ObjectManager $manager,$id)
    {
        //entity manager 
       $secretary = new Secretary();
        $secretaryRepository=$this->getDoctrine()->getRepository(Secretary::class);
        $secretary = $secretaryRepository->find($id);
        $user=$secretary->getUser();
        $form = $this->createForm(SecretaryFormType::class, $secretary);
        $form->handleRequest($request);
        //dump($user);exit;
        if ($form->isSubmitted()) { 
           
            $secretaryData = $form->getData();
            $newUser = $secretaryData->getUser();
            $secretary->setUser($newUser);
            //photo
            if($newUser->getPhoto()){
                $file = $newUser->getPhoto();
                $fileName = md5(uniqid()).'.'.$file->guessExtension();
                $file->move(
                    $this->getParameter('photos_directory'),
                    $fileName
                );
                $user->setPhoto($fileName);
            }
           
            $user->setUpdatedAt(new \DateTime());
           
            
            // flush DB
            $manager->flush();   

            return $this->redirectToRoute('listSecretaires');
        }
        return $this->render('g_secretaire/ModifierSecretaire.html.twig', array(
                'SecretaryForm' => $form->createView(),
                'secretary' => $secretary,
                'user' => $user
            )
        );
    }
    
    
     
   

}
