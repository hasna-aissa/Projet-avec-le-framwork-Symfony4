<?php

namespace App\Repository;

use App\Entity\Supervisor;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Symfony\Bridge\Doctrine\RegistryInterface;

/**
 * @method Supervisor|null find($id, $lockMode = null, $lockVersion = null)
 * @method Supervisor|null findOneBy(array $criteria, array $orderBy = null)
 * @method Supervisor[]    findAll()
 * @method Supervisor[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class SupervisorRepository extends ServiceEntityRepository
{
    public function __construct(RegistryInterface $registry)
    {
        parent::__construct($registry, Supervisor::class);
    }

    public function myFindAllEncadrant($number)
    {
        return $this->findAllEncadrantQuery($number)
                ->getQuery();
    }
    private function findAllEncadrantQuery($number) 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,e.id,e.service,u.id AS idUser')
                  ->from('App:User', 'u')   
                  ->join('App:Supervisor' ,'e')
                  ->where('u.id=e.user')
                  ->andWhere("u.isActive='".$number."'");
    }

/**
      * @return Query
      */
    public function getLastNameOfUser()
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,e.id,e.service,u.id AS idUser')
                  ->from('App:User', 'u')   
                  ->join('App:Supervisor' ,'e')
                  ->where('u.id=e.user')
                  ->andWhere('u.isActive=1')->getQuery();
    }

    public function GetInternsOfSupervisor($id)
    {
       return $this->_em->createQuery("SELECT u.lastName,u.firstName,u.id,t.title,u.photo FROM App:Intern i,App:Supervisor s,App:Topic t,App:Internship interns,App:User u WHERE u.id=i.user AND interns.topic=t.id AND s.id=t.supervisor AND i.id=interns.intern AND s.id='".$id."'")->getResult();
    }

    /**
      * @return Query
      */
    public function GetInternsOfSupervisors($number)
    {
        return $this->listeOfInterns($number)
                    ->getQuery();
    }

    private function listeOfInterns($number)
    {
        
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.lastName,u.firstName,u.id,t.title,u.photo')
                  ->from('App:User', 'u')   
                  ->join('App:Supervisor' ,'s')
                  ->join('App:Intern' ,'i')
                  ->join('App:Topic' ,'t')
                  ->join('App:Internship' ,'interns')
                  ->where('u.id=i.user')
                  ->andWhere('interns.topic=t.id')
                  ->andWhere('s.id=t.supervisor')
                  ->andWhere('i.id=interns.intern')
                  ->andWhere("s.id='".$number."'");
    }

    public function listOfTopic($id)
    {
        return $this->_em->createQuery("SELECT u.lastName,t.title 
            FROM App:Intern i,App:Supervisor s,App:Topic t,App:Internship interns,App:User u 
            WHERE u.id=i.user AND interns.topic=t.id AND s.id=t.supervisor AND i.id=interns.intern AND t.id IN(
            SELECT topi.id FROM App:Intern intern,App:Supervisor sup,App:Topic topi,App:Internship internsh,App:User us
            WHERE us.id=intern.user AND internsh.topic=topi.id AND sup.id=topi.supervisor AND intern.id=internsh.intern AND sup.id='".$id."')")->getResult();
    }

    public function listOfInternsOfTopic($id)
    {
        return $this->_em->createQuery("SELECT u.lastName,u.firstName,u.id,t.title,u.photo FROM App:Intern i,App:Supervisor s,App:Topic t,App:Internship interns,App:User u WHERE u.id=i.user AND interns.topic=t.id AND s.id=t.supervisor AND i.id=interns.intern AND t.id='".$id."'")->getResult();
    }

    public function SearchSupervisors($mot,$number)
    {
        return $this->_em->createQuery("SELECT u.firstName,u.lastName,u.photo,e.id,e.service,u.id AS idUser,e.city FROM App:Supervisor e,App:User u WHERE u.id=e.user AND u.isActive='".$number."' AND (u.firstName LIKE '%".$mot."%' OR u.lastName LIKE '%".$mot."%')")->getResult();
    }


    
    public function searchResultsEncadrant($cle,$number)
    {
        return $this->search($cle,$number)
                    ->getQuery();
    }
    
     private function search($cle,$number) 
    {
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.firstName,u.lastName,u.photo,e.id,e.service,u.id AS idUser,e.city')
                  ->from('App:User', 'u')   
                  ->join('App:Supervisor' ,'e')
                  ->where('u.id=e.user')
                  ->andWhere("e.service='".$cle."'")
                  ->andWhere("u.isActive='".$number."'");
    }


    public function listeOfSupervisors($number)
    {
        
        $qb = $this->_em->createQueryBuilder();
        return $qb->select('u.lastName,u.firstName')
                  ->from('App:User', 'u')   
                  ->join('App:Supervisor' ,'s')
                  ->where('u.id=s.user')
                  ->andWhere("s.id='".$number."'");
    }

    // /**
    //  * @return Supervisor[] Returns an array of Supervisor objects
    //  */
    /*
    public function findByExampleField($value)
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->orderBy('s.id', 'ASC')
            ->setMaxResults(10)
            ->getQuery()
            ->getResult()
        ;
    }
    */

    /*
    public function findOneBySomeField($value): ?Supervisor
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.exampleField = :val')
            ->setParameter('val', $value)
            ->getQuery()
            ->getOneOrNullResult()
        ;
    }
    */
}
