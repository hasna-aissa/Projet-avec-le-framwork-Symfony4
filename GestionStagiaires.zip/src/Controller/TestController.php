<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\User;

class TestController extends AbstractController
{
    /**
     * @Route("/test", name="test")
     */
    public function index()
    {
    	$manager=$this->getDoctrine()->getManager();
        $UserRepository= $manager->getRepository('App:User'); 
        $userCurrent = $this->getUser();
        $id=$userCurrent->getId();
       
        $intern=$UserRepository->findIntern($id);
        //dump($topics[0]['countI']);exit;
        //if is an intern
        if($intern[0]['countI']==1)
        {
        	return $this->redirectToRoute('stagiaire_liste');
        }
        //if is a secretary
        $secretary=$UserRepository->findSecretary($id);
         if($secretary[0]['countS']==1)
        {
        	return $this->redirectToRoute('listSecretaires');
        }
        //if is a supervisor
          $supervisor=$UserRepository->findSupervisor($id);
         if($supervisor[0]['countSup']==1)
        {
        	return $this->redirectToRoute('encadrants_liste');
        }
        
        return $this->render('test/index.html.twig');
    }
}
