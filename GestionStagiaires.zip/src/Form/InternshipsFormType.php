<?php

namespace App\Form;

use App\Entity\Internship;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;

class InternshipsFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('startDate')
            ->add('duration')
            ->add('topic', EntityType::class,array(
                'class' =>'App\Entity\Topic',
                'choice_value' => 'id',
                /*'choice_value' => function (Topic $topic = null) {
                    return $topic ? $topic->getId() : '';
                },*/
                //'expanded' => false,
                //'placeholder' => 'Choisir un sujet',
                'multiple' =>false,
                'choice_label' => function ($topic) {
                    return $topic->getTitle();  // Mettre ici le nom de ta méthode à la place si tu n'as pas d'attribut n...
                }

             ));
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Internship::class,
        ]);
    }
}
