<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class GDemandesController extends AbstractController
{
    /**
     * @Route("/g/demandes", name="g_demandes")
     */
    public function index()
    {
        return $this->render('g_demandes/index.html.twig', [
            'controller_name' => 'GDemandesController',
        ]);
    }

         /**
     * @Route("st-imalia/admin/demandes/absence", name="demande_absence")
     */
    public function demande_absence()
    {
        return $this->render('g_demandes/demandes_autorisation_absence.html.twig', [
            'controller_name' => 'GDemandesController',
        ]);
    }

    /**
     * @Route("st-imalia/admin/demandes/attestation", name="demande_attestation")
     */
    public function demande_attestation()
    {
        return $this->render('g_demandes/demandes_attestation.html.twig', [
            'controller_name' => 'GDemandesController',
        ]);
    }
}
