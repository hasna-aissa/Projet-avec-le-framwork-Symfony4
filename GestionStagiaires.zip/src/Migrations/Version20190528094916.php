<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20190528094916 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE absence_permission ADD intern_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE absence_permission ADD CONSTRAINT FK_E3472EA9525DD4B4 FOREIGN KEY (intern_id) REFERENCES intern (id)');
        $this->addSql('CREATE INDEX IDX_E3472EA9525DD4B4 ON absence_permission (intern_id)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE absence_permission DROP FOREIGN KEY FK_E3472EA9525DD4B4');
        $this->addSql('DROP INDEX IDX_E3472EA9525DD4B4 ON absence_permission');
        $this->addSql('ALTER TABLE absence_permission DROP intern_id');
    }
}
